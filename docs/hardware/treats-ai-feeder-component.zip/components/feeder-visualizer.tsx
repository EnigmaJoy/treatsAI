"use client"

import { useState } from "react"

type Variant = "black" | "white"

type StatusKey = "online" | "recognizing" | "rejected" | "dispensing" | "low"

type Status = {
  key: StatusKey
  label: string
  description: string
  color: string
  glow: string
  animation?: "led-pulse" | "led-flash"
}

const VARIANTS: Record<
  Variant,
  {
    label: string
    swatch: string
    body: string
    bodyEdge: string
    reservoir: string
    cap: string
    text: string
  }
> = {
  black: {
    label: "Midnight Black",
    swatch: "#1c1c1e",
    // subtle left-to-right cylindrical shading
    body: "linear-gradient(90deg, #0e0e10 0%, #303034 42%, #3a3a3f 52%, #26262a 70%, #101012 100%)",
    bodyEdge: "#000000",
    reservoir: "linear-gradient(90deg, #141416 0%, #38383d 50%, #17171a 100%)",
    cap: "linear-gradient(90deg, #17171a 0%, #3a3a3f 50%, #17171a 100%)",
    text: "#f5f5f7",
  },
  white: {
    label: "Arctic White",
    swatch: "#ededed",
    body: "linear-gradient(90deg, #d7d7d9 0%, #ffffff 44%, #fbfbfc 54%, #e9e9eb 70%, #cfcfd2 100%)",
    bodyEdge: "#c4c4c7",
    reservoir: "linear-gradient(90deg, #dcdcde 0%, #ffffff 50%, #dcdcde 100%)",
    cap: "linear-gradient(90deg, #dedee0 0%, #ffffff 50%, #dedee0 100%)",
    text: "#1c1c1e",
  },
}

const STATUSES: Status[] = [
  {
    key: "online",
    label: "Online, ready",
    description: "Solid green",
    color: "#22c55e",
    glow: "rgba(34,197,94,0.65)",
  },
  {
    key: "recognizing",
    label: "Recognizing cat",
    description: "Pulsing amber",
    color: "#f59e0b",
    glow: "rgba(245,158,11,0.7)",
    animation: "led-pulse",
  },
  {
    key: "rejected",
    label: "Recognition rejected",
    description: "Flashing red",
    color: "#ef4444",
    glow: "rgba(239,68,68,0.75)",
    animation: "led-flash",
  },
  {
    key: "dispensing",
    label: "Dispensing",
    description: "Solid blue",
    color: "#3b82f6",
    glow: "rgba(59,130,246,0.7)",
  },
  {
    key: "low",
    label: "Low food level",
    description: "Solid purple",
    color: "#a855f7",
    glow: "rgba(168,85,247,0.75)",
  },
]

export function FeederVisualizer() {
  const [variant, setVariant] = useState<Variant>("black")
  const [statusKey, setStatusKey] = useState<StatusKey>("online")

  const v = VARIANTS[variant]
  const status = STATUSES.find((s) => s.key === statusKey)!

  return (
    <div className="grid w-full max-w-5xl grid-cols-1 items-center gap-10 lg:grid-cols-[1.1fr_1fr]">
      {/* Product view */}
      <div className="flex justify-center">
        <FeederDevice variant={v} status={status} />
      </div>

      {/* Controls */}
      <div className="flex flex-col gap-8">
        <header className="space-y-2">
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-muted-foreground">
            Smart Pet Feeder
          </p>
          <h1 className="text-pretty text-3xl font-semibold tracking-tight sm:text-4xl">
            TreatsAI Feeder
          </h1>
          <p className="max-w-sm text-pretty leading-relaxed text-muted-foreground">
            A premium countertop feeder with on-device cat recognition, a
            stainless steel bowl, and an all-around status light.
          </p>
        </header>

        <div className="space-y-3">
          <h2 className="text-sm font-medium text-foreground">Finish</h2>
          <div className="flex flex-wrap gap-3">
            {(Object.keys(VARIANTS) as Variant[]).map((key) => {
              const opt = VARIANTS[key]
              const active = key === variant
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setVariant(key)}
                  aria-pressed={active}
                  className={`flex items-center gap-3 rounded-full border px-4 py-2 text-sm font-medium transition-all ${
                    active
                      ? "border-foreground bg-foreground text-background"
                      : "border-border bg-card text-foreground hover:border-foreground/40"
                  }`}
                >
                  <span
                    className="h-5 w-5 rounded-full border border-black/10 shadow-inner"
                    style={{ background: opt.swatch }}
                    aria-hidden="true"
                  />
                  {opt.label}
                </button>
              )
            })}
          </div>
        </div>

        <div className="space-y-3">
          <h2 className="text-sm font-medium text-foreground">LED Status</h2>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {STATUSES.map((s) => {
              const active = s.key === statusKey
              return (
                <button
                  key={s.key}
                  type="button"
                  onClick={() => setStatusKey(s.key)}
                  aria-pressed={active}
                  className={`flex items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-all ${
                    active
                      ? "border-foreground/70 bg-card shadow-sm"
                      : "border-border bg-card/60 hover:border-foreground/30"
                  }`}
                >
                  <span
                    className={`h-3.5 w-3.5 shrink-0 rounded-full ${s.animation ?? ""}`}
                    style={{
                      background: s.color,
                      boxShadow: `0 0 8px 1px ${s.glow}`,
                    }}
                    aria-hidden="true"
                  />
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-medium text-foreground">
                      {s.label}
                    </span>
                    <span className="block text-xs text-muted-foreground">
                      {s.description}
                    </span>
                  </span>
                </button>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

function FeederDevice({
  variant,
  status,
}: {
  variant: (typeof VARIANTS)[Variant]
  status: Status
}) {
  return (
    <div className="relative flex flex-col items-center" style={{ width: 260 }}>
      {/* Callouts */}
      <Callout
        className="right-full top-[26%] mr-3 hidden text-right sm:block"
        label="Reservoir"
      />
      <Callout
        className="left-full top-[54%] ml-3 hidden sm:block"
        label="LED ring"
      />
      <Callout
        className="right-full top-[68%] mr-3 hidden text-right sm:block"
        label="Camera module"
      />
      <Callout
        className="left-full bottom-[6%] ml-3 hidden sm:block"
        label="Steel bowl"
      />

      {/* Cap / removable lid */}
      <div
        className="relative z-20 h-5 w-[150px] rounded-t-[80px]"
        style={{
          background: variant.cap,
          boxShadow: "inset 0 2px 3px rgba(255,255,255,0.25)",
        }}
      />

      {/* Reservoir (top, slightly narrower) */}
      <div
        className="relative z-10 h-[150px] w-[178px] rounded-t-[26px]"
        style={{
          background: variant.reservoir,
          borderTop: `1px solid ${variant.bodyEdge}`,
        }}
      >
        {/* seam line where reservoir meets body */}
        <div
          className="absolute inset-x-3 bottom-0 h-px"
          style={{ background: "rgba(0,0,0,0.18)" }}
        />
      </div>

      {/* Main body */}
      <div
        className="relative w-[200px] rounded-b-[18px]"
        style={{ background: variant.body, height: 200 }}
      >
        {/* LED ring wrapping the body */}
        <div className="absolute inset-x-0 top-[34px]">
          <div
            className={`mx-auto h-[10px] w-full ${status.animation ?? ""}`}
            style={{
              background: status.color,
              boxShadow: `0 0 18px 3px ${status.glow}, 0 0 6px 1px ${status.glow}`,
            }}
          />
          {/* curved edges illusion */}
          <div
            className={`pointer-events-none absolute inset-x-0 top-0 h-[10px] ${status.animation ?? ""}`}
            style={{
              background:
                "linear-gradient(90deg, rgba(0,0,0,0.35) 0%, rgba(255,255,255,0.25) 45%, rgba(255,255,255,0.25) 55%, rgba(0,0,0,0.35) 100%)",
              mixBlendMode: "overlay",
            }}
          />
        </div>

        {/* Camera module (low on body) */}
        <div className="absolute inset-x-0 bottom-[26px] flex justify-center">
          <div
            className="flex h-[46px] w-[46px] items-center justify-center rounded-full"
            style={{
              background: "linear-gradient(145deg, #2a2a2e, #050506)",
              boxShadow:
                "inset 0 1px 2px rgba(255,255,255,0.2), 0 2px 4px rgba(0,0,0,0.35)",
            }}
          >
            {/* glossy polycarbonate lens */}
            <div
              className="h-[26px] w-[26px] rounded-full"
              style={{
                background:
                  "radial-gradient(circle at 32% 28%, #6b7280 0%, #1f2937 42%, #000000 100%)",
                boxShadow:
                  "inset 0 0 4px rgba(255,255,255,0.4), 0 1px 1px rgba(0,0,0,0.6)",
              }}
            >
              <div
                className="ml-[6px] mt-[5px] h-[6px] w-[6px] rounded-full"
                style={{ background: "rgba(255,255,255,0.55)" }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Stainless steel bowl at base */}
      <div
        className="relative z-10 -mt-1 h-[54px] w-[230px] rounded-b-[46px] rounded-t-[10px]"
        style={{
          background:
            "linear-gradient(90deg, #8a8d92 0%, #e8ebee 22%, #c4c8cd 40%, #f4f6f8 55%, #b7bbc0 74%, #7f8388 100%)",
          boxShadow: "inset 0 2px 4px rgba(255,255,255,0.5)",
        }}
      >
        {/* bowl inner rim */}
        <div
          className="absolute inset-x-[26px] top-[6px] h-[14px] rounded-[40px]"
          style={{
            background:
              "linear-gradient(180deg, rgba(0,0,0,0.25), rgba(255,255,255,0.15))",
          }}
        />
      </div>

      {/* Non-slip base pad */}
      <div
        className="h-[10px] w-[210px] rounded-b-[10px]"
        style={{ background: "#2b2b2e" }}
      />

      {/* Soft shadow */}
      <div
        className="mt-4 h-4 w-[230px] rounded-[50%]"
        style={{
          background:
            "radial-gradient(ellipse at center, rgba(0,0,0,0.22), rgba(0,0,0,0) 70%)",
        }}
        aria-hidden="true"
      />
    </div>
  )
}

function Callout({
  className,
  label,
}: {
  className?: string
  label: string
}) {
  return (
    <div className={`absolute z-30 whitespace-nowrap ${className ?? ""}`}>
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
    </div>
  )
}
