import { FeederVisualizer } from "@/components/feeder-visualizer"

export default function Page() {
  return (
    <main
      className="flex min-h-svh w-full items-center justify-center px-5 py-16"
      style={{
        background:
          "radial-gradient(120% 120% at 50% 0%, #fbfbfd 0%, #f1f2f5 55%, #e7e9ee 100%)",
      }}
    >
      <FeederVisualizer />
    </main>
  )
}
